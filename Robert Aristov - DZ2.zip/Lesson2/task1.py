lst = [12, 149.32, 'good', True]
for el in lst:
    print(f'У значени {el} тип - {type(el)}')
